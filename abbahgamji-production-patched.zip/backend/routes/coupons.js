const express = require('express');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();

// Slows down guessing/brute-forcing coupon codes.
const couponLimiter = rateLimit({ windowMs: 10 * 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false });

// Shared validity + discount-amount calculation, used here (to preview a
// discount) and from routes/orders.js (to actually apply one at checkout) so
// the two can never disagree about what a coupon is worth.
function evaluateCoupon(code, subtotal) {
  const coupon = db.get('coupons').find(c => c.code === String(code || '').trim().toUpperCase()).value();
  if (!coupon) return { valid: false, error: 'Coupon code not recognized.' };
  if (!coupon.active) return { valid: false, error: 'This coupon is no longer active.' };
  if (coupon.expiresAt && new Date(coupon.expiresAt) < new Date()) return { valid: false, error: 'This coupon has expired.' };
  if (subtotal < (coupon.minSpend || 0)) {
    return { valid: false, error: `This coupon requires a minimum spend of ₦${coupon.minSpend.toLocaleString()}.` };
  }
  const discount = coupon.type === 'percent'
    ? Math.round(subtotal * (coupon.value / 100))
    : Math.min(coupon.value, subtotal);
  return { valid: true, coupon, discount };
}

// GET /api/coupons/validate?code=WELCOME10&subtotal=45000 — public: preview a discount before checkout
router.get('/validate', couponLimiter, (req, res) => {
  const { code, subtotal } = req.query;
  if (!code) return res.status(400).json({ valid: false, error: 'Enter a coupon code.' });
  const result = evaluateCoupon(code, Number(subtotal) || 0);
  res.json(result);
});

// GET /api/coupons — admin: list all coupons
router.get('/', requireAdmin, (req, res) => {
  res.json(db.get('coupons').value());
});

// POST /api/coupons — admin: create a coupon
router.post('/', requireAdmin, (req, res) => {
  const { code, type, value, minSpend, expiresAt } = req.body;
  if (!code || !['percent', 'fixed'].includes(type) || !(Number(value) > 0)) {
    return res.status(400).json({ error: 'Code, type (percent/fixed) and a positive value are required.' });
  }
  const normalized = String(code).trim().toUpperCase();
  if (db.get('coupons').find({ code: normalized }).value()) {
    return res.status(409).json({ error: 'A coupon with this code already exists.' });
  }
  const coupon = {
    code: normalized, type, value: Number(value), active: true,
    minSpend: Number(minSpend) || 0, expiresAt: expiresAt || null, usedCount: 0
  };
  db.get('coupons').push(coupon).write();
  res.status(201).json(coupon);
});

// PATCH /api/coupons/:code — admin: toggle active / edit
router.patch('/:code', requireAdmin, (req, res) => {
  const code = req.params.code.toUpperCase();
  const coupon = db.get('coupons').find({ code }).value();
  if (!coupon) return res.status(404).json({ error: 'Coupon not found.' });
  db.get('coupons').find({ code }).assign(req.body).write();
  res.json(db.get('coupons').find({ code }).value());
});

// DELETE /api/coupons/:code — admin
router.delete('/:code', requireAdmin, (req, res) => {
  db.get('coupons').remove({ code: req.params.code.toUpperCase() }).write();
  res.json({ ok: true });
});

module.exports = { router, evaluateCoupon };
