const express = require('express');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();

// GET /api/analytics/summary — admin: everything the dashboard's
// analytics view needs in a single call (revenue trend, top products,
// low-stock alerts, customer stats).
router.get('/summary', requireAdmin, (req, res) => {
  const orders = db.get('orders').value();
  const products = db.get('products').value();
  const users = db.get('users').value();
  const paidOrders = orders.filter(o => o.paid);

  // Revenue for each of the last 14 days (chart-friendly, zero-filled).
  const days = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(d.toISOString().slice(0, 10));
  }
  const revenueByDay = days.map(day => ({
    day,
    revenue: paidOrders.filter(o => o.createdAt.slice(0, 10) === day).reduce((s, o) => s + o.total, 0)
  }));

  // Top products by units sold across paid orders.
  const unitsSold = {};
  paidOrders.forEach(o => o.items.forEach(i => { unitsSold[i.productId] = (unitsSold[i.productId] || 0) + i.qty; }));
  const topProducts = Object.entries(unitsSold)
    .map(([productId, qty]) => {
      const product = products.find(p => p.id === Number(productId));
      return product ? { id: product.id, name: product.name, qty, revenue: qty * product.price } : null;
    })
    .filter(Boolean)
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 5);

  const lowStock = products
    .filter(p => (p.stock ?? 0) <= (p.lowStockThreshold ?? 5))
    .map(p => ({ id: p.id, name: p.name, stock: p.stock, threshold: p.lowStockThreshold }));

  const totalRevenue = paidOrders.reduce((s, o) => s + o.total, 0);

  res.json({
    revenueByDay,
    totalRevenue,
    totalOrders: orders.length,
    paidOrders: paidOrders.length,
    avgOrderValue: paidOrders.length ? Math.round(totalRevenue / paidOrders.length) : 0,
    topProducts,
    lowStock,
    totalCustomers: users.length,
    totalProducts: products.length
  });
});

module.exports = router;
