const express = require('express');
const { v4: uuid } = require('uuid');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();

// Limits how fast one visitor can post reviews — reviews are public-write,
// so this is the main defence against spam/flooding a product's rating.
const reviewLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many reviews submitted. Please try again later.' }
});

// GET /api/reviews?productId=17 — public: approved reviews for a product,
// plus the average rating and count (used for the star rating on cards).
router.get('/', (req, res) => {
  const { productId } = req.query;
  let reviews = db.get('reviews').value().filter(r => r.approved);
  if (productId) reviews = reviews.filter(r => r.productId === Number(productId));
  const count = reviews.length;
  const average = count ? Math.round((reviews.reduce((s, r) => s + r.rating, 0) / count) * 10) / 10 : 0;
  res.json({ reviews: reviews.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)), average, count });
});

// GET /api/reviews/summary — public: average rating + count for every product in one call,
// so the shop grid can show stars without one request per card.
router.get('/summary', (req, res) => {
  const reviews = db.get('reviews').value().filter(r => r.approved);
  const byProduct = {};
  reviews.forEach(r => {
    if (!byProduct[r.productId]) byProduct[r.productId] = { total: 0, count: 0 };
    byProduct[r.productId].total += r.rating;
    byProduct[r.productId].count += 1;
  });
  const summary = {};
  Object.entries(byProduct).forEach(([productId, { total, count }]) => {
    summary[productId] = { average: Math.round((total / count) * 10) / 10, count };
  });
  res.json(summary);
});

// POST /api/reviews  { productId, name, rating, comment }
// Public — no account required, matching how the storefront currently works.
// Requires admin approval before appearing publicly.
router.post('/', reviewLimiter, (req, res) => {
  const { productId, name, rating, comment } = req.body;
  const product = db.get('products').find({ id: Number(productId) }).value();
  if (!product) return res.status(404).json({ error: 'Product not found.' });
  const ratingNum = Number(rating);
  if (!Number.isInteger(ratingNum) || ratingNum < 1 || ratingNum > 5) {
    return res.status(400).json({ error: 'Rating must be a whole number from 1 to 5.' });
  }
  if (!name || !String(name).trim()) return res.status(400).json({ error: 'Name is required.' });
  if (!comment || !String(comment).trim()) return res.status(400).json({ error: 'A short comment is required.' });
  if (String(comment).length > 800) return res.status(400).json({ error: 'Comment is too long (800 characters max).' });

  const review = {
    id: uuid(), productId: Number(productId), name: String(name).trim().slice(0, 80),
    rating: ratingNum, comment: String(comment).trim(), createdAt: new Date().toISOString(), approved: false
  };
  db.get('reviews').push(review).write();
  res.status(201).json(review);
});

// DELETE /api/reviews/:id — admin: unpublish an inappropriate review
router.delete('/:id', requireAdmin, (req, res) => {
  db.get('reviews').remove({ id: req.params.id }).write();
  res.json({ ok: true });
});

module.exports = router;


// Admin moderation endpoints
router.get('/pending', requireAdmin, (req,res)=>{
  res.json(db.get('reviews').value().filter(r=>!r.approved));
});

router.post('/:id/approve', requireAdmin, (req,res)=>{
  db.get('reviews').find({id:req.params.id}).assign({approved:true}).write();
  res.json({ok:true});
});
