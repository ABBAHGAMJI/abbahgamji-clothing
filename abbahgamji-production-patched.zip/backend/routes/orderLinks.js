// Shared magic-link helpers for order tracking/verification — used by both
// routes/orders.js (order-received email) and routes/payments.js (payment-
// confirmed email) so there's exactly one place that knows how these tokens
// are minted, hashed and redeemed.

const crypto = require('crypto');
const db = require('../db');

const ORDER_LINK_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days — covers the full tailoring + delivery cycle

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function frontendBaseUrl() {
  return (process.env.FRONTEND_URL || `http://localhost:${process.env.PORT || 4000}`).replace(/\/$/, '');
}

// Mints a fresh tracking token for an order + email, stores only its hash
// (never the raw token — a leaked db.json shouldn't be enough to forge
// links), and returns the full URL to put in an email. Returns null if the
// order has no usable email on it.
function createOrderTrackingLink(order) {
  const email = order.customer?.email && String(order.customer.email).trim().toLowerCase();
  if (!email || !/^\S+@\S+\.\S+$/.test(email)) return null;

  const rawToken = crypto.randomBytes(32).toString('hex');
  db.get('orderLinks').push({
    tokenHash: hashToken(rawToken),
    orderId: order.id,
    email,
    expiresAt: Date.now() + ORDER_LINK_TTL_MS,
    verifiedAt: null
  }).write();

  return { email, trackUrl: `${frontendBaseUrl()}/?orderToken=${rawToken}` };
}

// Redeems a raw token from the URL: validates it, marks first-use as email
// verification, and returns the matching order (or null if invalid/expired).
function redeemOrderTrackingLink(rawToken) {
  const tokenHash = hashToken(rawToken);
  const link = db.get('orderLinks').find({ tokenHash }).value();
  if (!link || link.expiresAt < Date.now()) return null;

  const order = db.get('orders').find({ id: link.orderId }).value();
  if (!order) return null;

  if (!link.verifiedAt) {
    db.get('orderLinks').find({ tokenHash }).assign({ verifiedAt: new Date().toISOString() }).write();
  }
  return order;
}

module.exports = { createOrderTrackingLink, redeemOrderTrackingLink };
