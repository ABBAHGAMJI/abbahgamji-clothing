const express = require('express');
const { v4: uuid } = require('uuid');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const { requireAdmin, attachUserIfPresent } = require('../middleware/auth');
const { evaluateCoupon } = require('./coupons');
const { sendOrderConfirmationEmail } = require('../mailer');
const { createOrderTrackingLink, redeemOrderTrackingLink } = require('./orderLinks');

const router = express.Router();

// Creates a fresh order-tracking link and emails the customer an
// order-received confirmation with a "verify email & track" button —
// clicking it both confirms they own that inbox and drops them straight
// into their order status, no order ID or phone number needed.
async function issueOrderVerificationEmail(order) {
  const link = createOrderTrackingLink(order);
  if (!link) return; // no usable email on this order — nothing to send

  const emailResult = await sendOrderConfirmationEmail(link.email, order, link.trackUrl);
  if (!emailResult.sent) {
    // No SMTP configured yet (or send failed) — log it so the flow is still
    // testable end to end locally, same fallback pattern as the magic-link login.
    console.log(`[order-link] No email sent for ${order.id} — verify/track link: ${link.trackUrl}`);
  }
}

// ₦ value of one loyalty point when redeemed at checkout, and how many
// points a customer earns per ₦ spent once an order is paid for.
const POINT_REDEEM_VALUE = 5; // 1 point = ₦5 off
const POINTS_PER_NAIRA_SPENT = 1 / 1000; // 1 point per ₦1,000 spent

const STAGES = ["Order Placed", "Cutting & Tailoring", "Quality Check", "Out For Delivery", "Delivered"];

// Stipulated delivery window shown to the customer and emailed to them.
// Made-to-measure items need real tailoring time, so if anything in the cart
// carries measurements, the whole order (they ship together) takes the
// longer window — otherwise it's ready-to-wear and just needs to be
// packed and shipped.
const STANDARD_DELIVERY_DAYS = { min: 3, max: 5 };
const MADE_TO_MEASURE_DELIVERY_DAYS = { min: 10, max: 14 };

function estimateDelivery(items) {
  const isMadeToMeasure = (items || []).some(i => i.measurements);
  const { min, max } = isMadeToMeasure ? MADE_TO_MEASURE_DELIVERY_DAYS : STANDARD_DELIVERY_DAYS;
  const now = new Date();
  const earliest = new Date(now); earliest.setDate(earliest.getDate() + min);
  const latest = new Date(now); latest.setDate(latest.getDate() + max);
  return {
    label: `${min}–${max} business days${isMadeToMeasure ? ' (made-to-measure)' : ''}`,
    minDays: min,
    maxDays: max,
    earliestDate: earliest.toISOString(),
    latestDate: latest.toISOString()
  };
}

// Order tracking is public and can be looked up by phone number, which isn't
// secret — this limits how fast someone could script through phone numbers
// trying to find real orders.
const trackLimiter = rateLimit({ windowMs: 10 * 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false });

// POST /api/orders — create an order (called after checkout, before payment is confirmed)
// Body: { items: [{ productId, qty, measurements }], customer: {...}, couponCode?, pointsToRedeem? }
// attachUserIfPresent: works for guests, but links the order to an account
// (and lets it redeem/earn loyalty points) when the customer is logged in.
router.post('/', attachUserIfPresent, (req, res) => {
  const { items, customer, couponCode, pointsToRedeem } = req.body;
  if (!items || !items.length || !customer) {
    return res.status(400).json({ error: 'Cart items and customer details are required.' });
  }
  if (!customer.name || !customer.phone || !customer.address) {
    return res.status(400).json({ error: 'Name, phone and delivery address are required.' });
  }

  try {
    const products = db.get('products').value();
    let subtotal = 0;
    const orderItems = items.map(i => {
      const product = products.find(p => p.id === i.productId);
      if (!product) throw new Error('One of the items in your cart is no longer available.');
      const qty = Number(i.qty);
      if (!Number.isInteger(qty) || qty < 1) throw new Error('Item quantity must be a whole number of 1 or more.');
      if (typeof product.stock === 'number' && product.stock < qty) {
        throw new Error(`Only ${product.stock} left of "${product.name}" — reduce the quantity in your cart.`);
      }
      subtotal += product.price * qty;
      return { productId: product.id, name: product.name, qty, price: product.price, measurements: i.measurements || null };
    });

    // Coupon discount
    let discount = 0;
    let appliedCoupon = null;
    if (couponCode) {
      const result = evaluateCoupon(couponCode, subtotal);
      if (!result.valid) throw new Error(result.error);
      discount += result.discount;
      appliedCoupon = result.coupon.code;
    }

    // Loyalty point redemption — only possible when logged in, and capped at
    // the customer's balance and at what's left of the order after the
    // coupon, so points can never push the total below zero.
    let pointsRedeemed = 0;
    const user = req.user ? db.get('users').find({ id: req.user.id }).value() : null;
    if (pointsToRedeem && user) {
      const requested = Math.max(0, Math.floor(Number(pointsToRedeem)));
      const affordable = Math.min(requested, user.loyaltyPoints || 0);
      const remainingAfterCoupon = subtotal - discount;
      const maxPointsUsable = Math.floor(remainingAfterCoupon / POINT_REDEEM_VALUE);
      pointsRedeemed = Math.min(affordable, maxPointsUsable);
      discount += pointsRedeemed * POINT_REDEEM_VALUE;
    }

    const total = Math.max(0, subtotal - discount);

    // Optional live-location pin from the checkout form (browser geolocation),
    // stored alongside the typed delivery address — never a substitute for it.
    let location = null;
    if (customer.location && Number.isFinite(Number(customer.location.lat)) && Number.isFinite(Number(customer.location.lng))) {
      location = { lat: Number(customer.location.lat), lng: Number(customer.location.lng) };
    }

    const order = {
      id: 'ABG-' + uuid().slice(0, 8).toUpperCase(),
      items: orderItems,
      subtotal,
      discount,
      couponCode: appliedCoupon,
      pointsRedeemed,
      pointsEarned: 0, // credited once payment is verified — see routes/payments.js
      total,
      customer: { ...customer, location },
      estimatedDelivery: estimateDelivery(orderItems),
      userId: user ? user.id : null,
      status: 'Order Placed',
      paid: false,
      txRef: null,
      createdAt: new Date().toISOString()
    };
    db.get('orders').push(order).write();
    res.status(201).json(order);

    // Fire-and-forget: don't hold up the order-creation response on email
    // delivery, and a slow/failed send should never fail the order itself.
    issueOrderVerificationEmail(order).catch(err =>
      console.error(`[order-link] Failed to send confirmation email for ${order.id}:`, err.message)
    );
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// GET /api/orders/verify?token=...
// Redeems an emailed order-verification/tracking link: confirms the
// customer owns the email the order was placed with (first click marks
// verifiedAt) and returns the same shape as /track so the front end can
// drop the customer straight into their order status.
router.get('/verify', trackLimiter, (req, res) => {
  const { token } = req.query;
  if (!token) return res.status(400).json({ error: 'Missing verification token.' });

  const order = redeemOrderTrackingLink(token);
  if (!order) {
    return res.status(401).json({ error: 'This link is invalid or has expired. Use the Track Order form with your order ID or phone number instead.' });
  }

  res.json({ id: order.id, total: order.total, status: order.status, stages: STAGES, createdAt: order.createdAt, estimatedDelivery: order.estimatedDelivery, emailVerified: true });
});

// GET /api/orders/track?query=ABG-XXXX  (matches order id or customer phone)
router.get('/track', trackLimiter, (req, res) => {
  const { query } = req.query;
  if (!query) return res.status(400).json({ error: 'Provide an order ID or phone number.' });
  const order = db.get('orders').find(o => o.id === query || o.customer.phone === query).value();
  if (!order) return res.status(404).json({ error: 'No order found for that ID or phone number.' });
  res.json({ id: order.id, total: order.total, status: order.status, stages: STAGES, createdAt: order.createdAt, estimatedDelivery: order.estimatedDelivery });
});

// GET /api/orders — admin: list all orders
router.get('/', requireAdmin, (req, res) => {
  res.json(db.get('orders').value());
});

// PATCH /api/orders/:id/status — admin: move an order to a new stage
router.patch('/:id/status', requireAdmin, (req, res) => {
  const { status } = req.body;
  if (!STAGES.includes(status)) return res.status(400).json({ error: 'Not a valid order stage.' });
  const order = db.get('orders').find({ id: req.params.id }).value();
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  db.get('orders').find({ id: req.params.id }).assign({ status }).write();
  res.json({ ok: true });
});

// GET /api/orders/export — admin: download all orders as CSV
router.get('/export', requireAdmin, (req, res) => {
  const orders = db.get('orders').value();
  const header = ['Order ID', 'Date', 'Customer', 'Phone', 'Email', 'Items', 'Subtotal', 'Discount', 'Total', 'Status', 'Paid'];
  const escapeCsv = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const rows = orders.map(o => [
    o.id, o.createdAt, o.customer.name, o.customer.phone, o.customer.email,
    o.items.map(i => `${i.name} x${i.qty}`).join('; '),
    o.subtotal ?? o.total, o.discount ?? 0, o.total, o.status, o.paid ? 'Yes' : 'No'
  ].map(escapeCsv).join(','));
  const csv = [header.join(','), ...rows].join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="abbahgamji-orders-${new Date().toISOString().slice(0, 10)}.csv"`);
  res.send(csv);
});

module.exports = router;
