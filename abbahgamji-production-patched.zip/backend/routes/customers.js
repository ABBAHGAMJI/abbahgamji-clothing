const express = require('express');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();

// GET /api/customers — admin: list accounts created on the storefront
router.get('/', requireAdmin, (req, res) => {
  const customers = db.get('users').value().map(u => ({
    id: u.id, name: u.name, email: u.email, measurements: u.measurements
  }));
  res.json(customers);
});

module.exports = router;
