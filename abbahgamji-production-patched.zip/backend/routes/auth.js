const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { v4: uuid } = require('uuid');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');
const { sendMagicLinkEmail } = require('../mailer');

const router = express.Router();

// Slows down brute-force login/registration attempts against a single IP.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Please wait a few minutes and try again.' }
});

function signToken(user) {
  return jwt.sign({ id: user.id, email: user.email, name: user.name }, process.env.JWT_SECRET, { expiresIn: '30d' });
}

// POST /api/auth/register  { name, email, password }
router.post('/register', authLimiter, (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email and password are all required.' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  }
  const existing = db.get('users').find({ email }).value();
  if (existing) return res.status(409).json({ error: 'An account with this email already exists.' });

  const passwordHash = bcrypt.hashSync(password, 10);
  const user = { id: uuid(), name, email, passwordHash, measurements: null, loyaltyPoints: 0 };
  db.get('users').push(user).write();

  res.status(201).json({ token: signToken(user), user: { id: user.id, name: user.name, email: user.email } });
});

// POST /api/auth/login  { email, password }
router.post('/login', authLimiter, (req, res) => {
  const { email, password } = req.body;
  const user = db.get('users').find({ email }).value();
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    return res.status(401).json({ error: 'Incorrect email or password.' });
  }
  res.json({ token: signToken(user), user: { id: user.id, name: user.name, email: user.email } });
});

// Slows down repeated magic-link requests for the same address/IP.
const magicLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many magic link requests. Please wait a few minutes and try again.' }
});

const MAGIC_LINK_TTL_MS = 15 * 60 * 1000; // links expire 15 minutes after being requested

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

// POST /api/auth/magic-link  { email }
// Passwordless login: generates a one-time link, emails it (or logs it if no
// SMTP is configured yet), and does NOT reveal whether the email already has
// an account — the same response is sent either way.
router.post('/magic-link', magicLimiter, async (req, res) => {
  const { email } = req.body;
  if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
    return res.status(400).json({ error: 'A valid email is required.' });
  }
  const normalizedEmail = String(email).trim().toLowerCase();

  const rawToken = crypto.randomBytes(32).toString('hex');
  db.get('magicLinks').push({
    tokenHash: hashToken(rawToken),
    email: normalizedEmail,
    expiresAt: Date.now() + MAGIC_LINK_TTL_MS,
    used: false
  }).write();

  const frontendUrl = (process.env.FRONTEND_URL || `http://localhost:${process.env.PORT || 4000}`).replace(/\/$/, '');
  const magicUrl = `${frontendUrl}/?magicToken=${rawToken}`;

  const emailResult = await sendMagicLinkEmail(normalizedEmail, magicUrl);

  const response = { ok: true, message: 'If that email has an account, a login link is on its way.' };
  // No SMTP configured yet (common while building locally) — surface the
  // link directly so the flow is still testable end to end.
  if (!emailResult.sent) {
    console.log(`[magic-link] No SMTP configured — login link for ${normalizedEmail}: ${magicUrl}`);
    response.devMagicUrl = magicUrl;
  }
  res.json(response);
});

// POST /api/auth/magic-login  { token }
// Redeems a one-time magic-link token. Creates the account on first use, so
// a brand-new customer can sign in with just their email.
router.post('/magic-login', (req, res) => {
  const { token } = req.body;
  if (!token) return res.status(400).json({ error: 'Missing login link token.' });

  const tokenHash = hashToken(token);
  const record = db.get('magicLinks').find({ tokenHash }).value();

  if (!record || record.used || record.expiresAt < Date.now()) {
    return res.status(401).json({ error: 'This login link is invalid or has expired. Request a new one.' });
  }
  db.get('magicLinks').find({ tokenHash }).assign({ used: true }).write();

  let user = db.get('users').find({ email: record.email }).value();
  if (!user) {
    // First time this email has logged in — create the account. No usable
    // password is set; they can add one later if they want password login too.
    const placeholderHash = bcrypt.hashSync(crypto.randomBytes(16).toString('hex'), 10);
    user = { id: uuid(), name: record.email.split('@')[0], email: record.email, passwordHash: placeholderHash, measurements: null, loyaltyPoints: 0 };
    db.get('users').push(user).write();
  }

  res.json({ token: signToken(user), user: { id: user.id, name: user.name, email: user.email } });
});

// GET /api/auth/me — current user + saved measurements
router.get('/me', requireAuth, (req, res) => {
  const user = db.get('users').find({ id: req.user.id }).value();
  if (!user) return res.status(404).json({ error: 'Account not found.' });
  res.json({ id: user.id, name: user.name, email: user.email, measurements: user.measurements, loyaltyPoints: user.loyaltyPoints || 0 });
});

// PUT /api/auth/measurements — save tailor's inscription to the account
router.put('/measurements', requireAuth, (req, res) => {
  db.get('users').find({ id: req.user.id }).assign({ measurements: req.body }).write();
  res.json({ ok: true });
});

module.exports = router;
