const express = require('express');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();

// GET /api/products — public catalog, optional ?category=Kaftan filter
router.get('/', (req, res) => {
  const { category } = req.query;
  let products = db.get('products').value();
  if (category && category !== 'all') {
    products = products.filter(p => p.cat === category);
  }
  res.json(products);
});

// POST /api/products — admin: add a product
router.post('/', requireAdmin, (req, res) => {
  const { name, cat, price, img, desc, stock, lowStockThreshold, oldPrice } = req.body;
  if (!name || !cat || !price) return res.status(400).json({ error: 'Name, category and price are required.' });
  if (Number(price) <= 0) return res.status(400).json({ error: 'Price must be greater than zero.' });
  // oldPrice is optional — when set (and higher than price) the storefront shows
  // it struck through next to the current price as a "was / now" sale price.
  const parsedOldPrice = oldPrice !== undefined && oldPrice !== null && oldPrice !== '' ? Number(oldPrice) : null;
  if (parsedOldPrice !== null && (!Number.isFinite(parsedOldPrice) || parsedOldPrice <= Number(price))) {
    return res.status(400).json({ error: 'Old price must be a number greater than the current price.' });
  }
  const products = db.get('products').value();
  const id = products.length ? Math.max(...products.map(p => p.id)) + 1 : 1;
  const product = {
    id, name, cat, price: Number(price), oldPrice: parsedOldPrice, img: img || '', desc: desc || '',
    stock: Number.isFinite(Number(stock)) ? Number(stock) : 20,
    lowStockThreshold: Number.isFinite(Number(lowStockThreshold)) ? Number(lowStockThreshold) : 5
  };
  db.get('products').push(product).write();
  res.status(201).json(product);
});

// PUT /api/products/:id — admin: edit a product
router.put('/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const product = db.get('products').find({ id }).value();
  if (!product) return res.status(404).json({ error: 'Product not found.' });
  const updates = { ...req.body };
  // Normalize oldPrice the same way POST does — "" or unset clears the sale price.
  if ('oldPrice' in updates) {
    updates.oldPrice = updates.oldPrice !== undefined && updates.oldPrice !== null && updates.oldPrice !== ''
      ? Number(updates.oldPrice) : null;
  }
  db.get('products').find({ id }).assign(updates).write();
  res.json(db.get('products').find({ id }).value());
});

// DELETE /api/products/:id — admin: remove a product
router.delete('/:id', requireAdmin, (req, res) => {
  db.get('products').remove({ id: Number(req.params.id) }).write();
  res.json({ ok: true });
});

module.exports = router;
