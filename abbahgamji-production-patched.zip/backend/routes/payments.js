const express = require('express');
const db = require('../db');
const { sendPaymentConfirmedEmail } = require('../mailer');
const { createOrderTrackingLink } = require('./orderLinks');

const router = express.Router();

const POINTS_PER_NAIRA_SPENT = 1 / 1000; // 1 loyalty point per ₦1,000 spent

// POST /api/payments/verify  { transaction_id, order_id }
// Called from the front end right after Flutterwave's checkout widget succeeds.
// This is the step that must happen on a server: it re-checks the payment with
// Flutterwave directly using your secret key, so a customer (or anyone editing
// the page in devtools) can't just claim they paid without actually paying.
router.post('/verify', async (req, res) => {
  const { transaction_id, order_id } = req.body;
  if (!transaction_id || !order_id) {
    return res.status(400).json({ error: 'transaction_id and order_id are required.' });
  }

  const order = db.get('orders').find({ id: order_id }).value();
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  if (order.paid) {
    // Already verified — don't re-charge logic or trust a second, possibly
    // unrelated transaction_id against an order that's already settled.
    return res.json({ ok: true, order });
  }

  try {
    const flwRes = await fetch(`https://api.flutterwave.com/v3/transactions/${transaction_id}/verify`, {
      headers: { Authorization: `Bearer ${process.env.FLW_SECRET_KEY}` }
    });
    const flwData = await flwRes.json();

    const tx = flwData.data;
    const isGenuine = flwData.status === 'success'
      && tx
      && tx.status === 'successful'
      && tx.currency === 'NGN'
      && tx.amount >= order.total
      // Critical: without this check, a transaction_id from a different
      // (already-paid) order could be replayed here to mark THIS order paid
      // too, as long as its amount happened to clear the bar above.
      // tx_ref is set to the order id at checkout time (see index.html),
      // so this ties the verified payment back to this specific order.
      && tx.tx_ref === order_id;

    if (!isGenuine) {
      return res.status(400).json({ error: 'Payment could not be verified.', detail: flwData });
    }

    // Decrement stock now that payment is genuinely confirmed — doing this
    // any earlier (e.g. at order creation) would let an abandoned, unpaid
    // checkout hold stock hostage from other customers.
    order.items.forEach(item => {
      const product = db.get('products').find({ id: item.productId }).value();
      if (product) {
        const newStock = Math.max(0, (product.stock || 0) - item.qty);
        db.get('products').find({ id: item.productId }).assign({ stock: newStock }).write();
      }
    });

    // Credit loyalty points, if this order is linked to an account.
    let pointsEarned = 0;
    if (order.userId) {
      pointsEarned = Math.floor(order.total * POINTS_PER_NAIRA_SPENT);
      const user = db.get('users').find({ id: order.userId }).value();
      if (user) {
        const remaining = Math.max(0, (user.loyaltyPoints || 0) - (order.pointsRedeemed || 0));
        db.get('users').find({ id: order.userId }).assign({ loyaltyPoints: remaining + pointsEarned }).write();
      }
    }

    db.get('orders').find({ id: order_id }).assign({ paid: true, txRef: tx.tx_ref, pointsEarned }).write();
    const paidOrder = db.get('orders').find({ id: order_id }).value();
    res.json({ ok: true, order: paidOrder });

    // Fire-and-forget: a fresh tracking link + confirmation email, sent only
    // now that payment is genuinely verified. Never let a slow/failed send
    // affect the response the customer's browser is already waiting on.
    const link = createOrderTrackingLink(paidOrder);
    if (link) {
      sendPaymentConfirmedEmail(link.email, paidOrder, link.trackUrl).catch(err =>
        console.error(`[order-link] Failed to send payment-confirmed email for ${order_id}:`, err.message)
      );
    }
  } catch (err) {
    res.status(502).json({ error: 'Could not reach Flutterwave to verify this payment.', detail: err.message });
  }
});

module.exports = router;
